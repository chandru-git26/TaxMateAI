
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { onAuthStateChanged, signOut, type User } from 'firebase/auth';
import { auth } from '@/lib/firebase';
import {
  SidebarProvider,
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarFooter,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
} from '@/components/ui/sidebar';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { CheckCircle, Circle, LogOut, ShieldCheck, User as UserIcon } from 'lucide-react';
import TaxForm from '@/components/dashboard/tax-form';
import { Steps, type Step } from '@/lib/types';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

export default function DashboardPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentStep, setCurrentStep] = useState<Step>(Steps[0]);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setUser(user);
      } else {
        router.push('/');
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [router]);

  const handleLogout = async () => {
    try {
      await signOut(auth);
      toast({
        title: 'Signed Out',
        description: 'You have been successfully signed out.',
      });
      router.push('/');
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to sign out. Please try again.',
      });
    }
  };

  const handleStepChange = (step: Step) => {
    if (step.id > currentStep.id && !completedSteps.includes(currentStep.id)) {
      setCompletedSteps([...completedSteps, currentStep.id]);
    }
    setCurrentStep(step);
  };

  const handleStepClick = (step: Step) => {
    if (completedSteps.includes(step.id) || step.id === currentStep.id || step.id < currentStep.id) {
      setCurrentStep(step);
    }
  };

  if (!isClient || loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        Loading...
      </div>
    );
  }
  
  return (
    <SidebarProvider>
      <div className="flex min-h-screen">
        <Sidebar>
          <SidebarHeader>
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-8 w-8 text-accent" />
              <h1 className="text-2xl font-bold">TaxMate</h1>
            </div>
          </SidebarHeader>
          <SidebarContent className="flex-1">
            <SidebarMenu>
              {Steps.map((step) => {
                const isCompleted = completedSteps.includes(step.id);
                const isActive = currentStep.id === step.id;
                const isClickable = isCompleted || isActive || step.id < currentStep.id;

                return (
                  <SidebarMenuItem key={step.id}>
                    <SidebarMenuButton
                      onClick={() => (isClickable ? handleStepClick(step) : undefined)}
                      isActive={isActive}
                      className={cn(!isClickable && "cursor-not-allowed opacity-50")}
                    >
                      {isCompleted ? (
                        <CheckCircle className="h-5 w-5 text-green-500" />
                      ) : (
                        <Circle className={cn('h-5 w-5', isActive && 'text-accent')} />
                      )}
                      <span>{step.name}</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarContent>
          <SidebarFooter>
            <div className="flex items-center gap-3 p-2 rounded-lg mb-2">
                <Avatar className="h-10 w-10">
                    <AvatarImage src={user?.photoURL || ''} alt={user?.displayName || 'User'} />
                    <AvatarFallback>
                      {user?.isAnonymous ? <UserIcon /> : user?.email?.charAt(0).toUpperCase() || 'U'}
                    </AvatarFallback>
                </Avatar>
                <div className="flex-1 overflow-hidden">
                    <p className="font-semibold truncate">{user?.isAnonymous ? 'Guest User' : user?.displayName || 'User'}</p>
                    {user && !user.isAnonymous && <p className="text-xs text-muted-foreground truncate">{user.email}</p>}
                </div>
            </div>
             <Button variant="outline" size="sm" onClick={handleLogout} className="w-full">
              <LogOut className="mr-2 h-4 w-4" />
              Sign Out
            </Button>
          </SidebarFooter>
        </Sidebar>
        <main className="flex-1 bg-background">
            <TaxForm currentStep={currentStep} onStepChange={handleStepChange} />
        </main>
      </div>
    </SidebarProvider>
  );
}
