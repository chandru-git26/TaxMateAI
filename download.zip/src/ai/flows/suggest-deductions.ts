
"use server"; 

import React from 'react';

/**
 * @fileOverview This file defines a Genkit flow for suggesting potential tax deductions to users based on their input data.
 *
 * - suggestDeductions - A function that takes tax data as input and returns a list of suggested deductions with explanations.
 * - SuggestDeductionsInput - The input type for the suggestDeductions function.
 * - SuggestDeductionsOutput - The return type for the suggestDeductions function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SuggestDeductionsInputSchema = z.object({
  income: z.number().describe("The user's total income for the tax year."),
  filingStatus: z
    .string()
    .describe(
      "The user's filing status (e.g., single, married filing jointly)." + " Must be one of: single, married filing jointly, married filing separately, head of household, qualifying widow(er)"
    ),
  dependents: z
    .number()
    .describe('The number of dependents the user is claiming.'),
  itemizedDeductions: z
    .boolean()
    .describe(
      'Whether the user plans to itemize deductions instead of taking the standard deduction.'
    ),
  medicalExpenses: z
    .number()
    .optional()
    .describe("The user's total medical expenses for the tax year."),
  mortgageInterest: z
    .number()
    .optional()
    .describe('The amount of mortgage interest paid during the tax year.'),
  charitableDonations: z
    .number()
    .optional()
    .describe('The total amount of charitable donations made during the tax year.'),
  pensionsAndBenefits: z
    .number()
    .optional()
    .describe('Income from pensions and benefits.'),
  propertyIncome: z
    .number()
    .optional()
    .describe('Income from property.'),
  investmentIncome: z
    .number()
    .optional()
    .describe('Income from investments.'),
  allowances: z.number().optional().describe('Any tax allowances claimed.'),
  reliefs: z.number().optional().describe('Any tax reliefs claimed.'),
  studentLoans: z
    .number()
    .optional()
    .describe('Amount of student loan interest paid.'),
});

export type SuggestDeductionsInput = z.infer<typeof SuggestDeductionsInputSchema>;

const DeductionSchema = z.object({
    name: z.string().describe('The name of the tax deduction.'),
    explanation: z.string().describe('A brief explanation of what this deduction is and why it has been classified as Highly Likely, Potential, or Not Applicable based on the user\'s data.'),
    applicability: z.enum(['Highly Likely', 'Potential', 'Not Applicable']).describe("The likelihood of the user being eligible for this deduction. 'Highly Likely' means you are confident. 'Potential' means it might apply but requires more information. 'Not Applicable' means the user is clearly not eligible, and you should explain why for their future reference.")
});

const SuggestDeductionsOutputSchema = z.object({
  suggestedDeductions: z
    .array(DeductionSchema)
    .describe('A list of potential tax deductions the user may be eligible for, with personalized explanations.'),
});

export type SuggestDeductionsOutput = z.infer<typeof SuggestDeductionsOutputSchema>;

export async function suggestDeductions(
  input: SuggestDeductionsInput
): Promise<SuggestDeductionsOutput> {
  return suggestDeductionsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'suggestDeductionsPrompt',
  input: {schema: SuggestDeductionsInputSchema},
  output: {schema: SuggestDeductionsOutputSchema},
  config: {
    temperature: 0,
  },
  prompt: `You are an AI tax assistant specializing in UK tax law. Your goal is to identify possible tax deductions and reliefs for the user and classify them into three categories: 'Highly Likely', 'Potential', or 'Not Applicable'.

  Consider all standard allowances, itemized deductions, and other potential reliefs based on the user's situation under UK tax regulations.

  For each possible deduction, you must:
  1.  Provide the deduction's name.
  2.  Classify its relevance to the user by setting the 'applicability' field to one of the following:
      - 'Highly Likely': Use this if you are confident the user meets the primary criteria.
      - 'Potential': Use this if the user might be eligible, but it depends on further conditions not specified in the input.
      - 'Not Applicable': Use this if the user is clearly not eligible.
  3.  Write a personalized 'explanation'.
      - For 'Highly Likely' and 'Potential', explain what the deduction is and why it might apply to the user.
      - For 'Not Applicable', explain what the deduction is and *specifically why the user does not qualify* based on their provided data. This is for their education.

  Here is the user's information:

  Income: £{{{income}}}
  Filing Status: {{{filingStatus}}}
  Dependents: {{{dependents}}}
  Itemized Deductions: {{{itemizedDeductions}}}
  {{#if itemizedDeductions}}
  Medical Expenses: £{{{medicalExpenses}}}
  Mortgage Interest: £{{{mortgageInterest}}}
  Charitable Donations: £{{{charitableDonations}}}
  {{/if}}
  Pensions and Benefits: £{{{pensionsAndBenefits}}}
  Property Income: £{{{propertyIncome}}}
  Investment Income: £{{{investmentIncome}}}
  Allowances: £{{{allowances}}}
  Reliefs: £{{{reliefs}}}
  Student Loans Paid: £{{{studentLoans}}}
  `,
});

const suggestDeductionsFlow = ai.defineFlow(
  {
    name: 'suggestDeductionsFlow',
    inputSchema: SuggestDeductionsInputSchema,
    outputSchema: SuggestDeductionsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
