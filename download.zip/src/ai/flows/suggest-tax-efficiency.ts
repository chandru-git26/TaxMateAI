
"use server";

/**
 * @fileOverview This file defines a Genkit flow for suggesting tax efficiency strategies.
 *
 * - suggestTaxEfficiency - A function that takes user financial data and returns a plan for savings and investments.
 * - SuggestTaxEfficiencyInput - The input type for the suggestTaxEfficiency function.
 * - SuggestTaxEfficiencyOutput - The return type for the suggestTaxEfficiency function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SuggestTaxEfficiencyInputSchema = z.object({
  income: z.number().describe("The user's total current annual income."),
  targetIncome: z.number().describe("The user's desired annual income in the future."),
  currentSavings: z.number().optional().describe("The user's current total savings and investments."),
  riskAppetite: z.enum(['low', 'medium', 'high']).describe("The user's appetite for investment risk."),
});

export type SuggestTaxEfficiencyInput = z.infer<typeof SuggestTaxEfficiencyInputSchema>;

const InvestmentSuggestionSchema = z.object({
  name: z.string().describe("The name of the investment type (e.g., Stocks and Shares ISA, Pension)."),
  description: z.string().describe("A brief explanation of the investment type and why it's being suggested for the user."),
  potentialReturn: z.string().describe("An estimated potential return for this type of investment (e.g., '4-6% per year')."),
});

const SuggestTaxEfficiencyOutputSchema = z.object({
  savingsPlan: z.object({
    monthlySavingsRequired: z.number().describe("The estimated monthly amount the user needs to save to reach their target income."),
    planDescription: z.string().describe("An explanation of how the user can achieve their savings goal based on their current income and spending habits."),
  }),
  investmentSuggestions: z.array(InvestmentSuggestionSchema).describe("A list of suggested tax-efficient investment options in the UK."),
});

export type SuggestTaxEfficiencyOutput = z.infer<typeof SuggestTaxEfficiencyOutputSchema>;

export async function suggestTaxEfficiency(
  input: SuggestTaxEfficiencyInput
): Promise<SuggestTaxEfficiencyOutput> {
  return suggestTaxEfficiencyFlow(input);
}

const prompt = ai.definePrompt({
  name: 'suggestTaxEfficiencyPrompt',
  input: {schema: SuggestTaxEfficiencyInputSchema},
  output: {schema: SuggestTaxEfficiencyOutputSchema},
  config: {
    temperature: 0.2, // A little creativity for financial advice is ok
  },
  prompt: `You are an expert UK financial advisor specializing in tax-efficient savings and investments. Your goal is to provide a clear, actionable plan to help a user reach their target income.

  Analyze the user's financial situation and provide a personalized savings and investment plan.

  1.  **Savings Plan**: Calculate the required monthly savings to bridge the gap between their current savings and the amount needed for their target income. Assume a reasonable timeframe (e.g., 10-20 years) and a conservative growth rate. Explain how they might achieve this based on their income.
  2.  **Investment Suggestions**: Recommend specific UK tax-efficient investment options (like ISAs, SIPPs, etc.) that align with their risk appetite. For each suggestion, provide a name, a description of why it's suitable, and an estimated potential return.

  User's Information:
  - Current Annual Income: £{{{income}}}
  - Target Annual Income: £{{{targetIncome}}}
  - Current Savings: £{{{currentSavings}}}
  - Risk Appetite: {{{riskAppetite}}}
  `,
});

const suggestTaxEfficiencyFlow = ai.defineFlow(
  {
    name: 'suggestTaxEfficiencyFlow',
    inputSchema: SuggestTaxEfficiencyInputSchema,
    outputSchema: SuggestTaxEfficiencyOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
