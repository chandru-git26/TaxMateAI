import { config } from 'dotenv';
config();

import '@/ai/flows/suggest-deductions.ts';
import '@/ai/flows/suggest-tax-efficiency.ts';
