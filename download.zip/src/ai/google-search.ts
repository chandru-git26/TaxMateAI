import axios from 'axios';

interface GoogleSearchResult {
  title: string;
  link: string;
  snippet: string;
}

async function searchGoogle(query: string): Promise<GoogleSearchResult[]> {
  const apiKey = 'AIzaSyBiDMMemXCDdEuXs2aQpPBcERnpf8okseI'; // Your API key
  const cx = 'b18971f9c21914b4c'; // Replace with your Custom Search Engine ID
  const apiUrl = 'https://www.googleapis.com/customsearch/v1';

  try {
    const response = await axios.get(apiUrl, {
      params: {
        key: apiKey,
        cx: cx,
        q: query,
      },
    });

    const searchResults: GoogleSearchResult[] = response.data.items.map((item: any) => ({
      title: item.title,
      link: item.link,
      snippet: item.snippet,
    }));

    return searchResults;
  } catch (error) {
    console.error('Error performing Google search:', error);
    return [];
  }
}
