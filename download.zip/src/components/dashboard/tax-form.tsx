
'use client';

import { useState, useEffect } from 'react';
import { useForm, type UseFormReturn } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { AnimatePresence, motion } from 'framer-motion';
import { Upload, CreditCard, FileText, User, FilePlus, Send, ArrowRight, ArrowLeft, Briefcase, Home, LineChart, HandCoins, School, Wallet, Trash2, File as FileIcon, Lightbulb, Lock, Heart, ExternalLink, Coffee, Eye, EyeOff } from 'lucide-react';
import { z } from 'zod';

import { cn } from '@/lib/utils';
import { TFormData, FormDataSchema, Steps, Step, FilingStatusEnum } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { AiDeductions } from './ai-deductions';
import { TaxSummaryCard } from './tax-summary-card';
import { useToast } from '@/hooks/use-toast';
import Link from 'next/link';


interface TaxFormProps {
    currentStep: Step;
    onStepChange: (step: Step) => void;
}

export default function TaxForm({ currentStep, onStepChange }: TaxFormProps) {
  const [formData, setFormData] = useState<Partial<TFormData>>({});


  const form = useForm<TFormData>({
    resolver: zodResolver(FormDataSchema),
    defaultValues: {
      fullName: '',
      filingStatus: 'single',
      addressLine1: '',
      addressLine2: '',
      city: '',
      postcode: '',
      income: 0,
      dependents: 0,
      itemizedDeductions: true, // Keep it true to validate fields even if hidden
      medicalExpenses: 0,
      mortgageInterest: 0,
      charitableDonations: 0,
      pensionsAndBenefits: 0,
      propertyIncome: 0,
      investmentIncome: 0,
      allowances: 0,
      reliefs: 0,
      studentLoans: 0,
      paymentsAndRepayments: 0,
    },
  });

  const { toast } = useToast();

  const processForm = (data: TFormData) => {
    setFormData(data);
    const currentStepIndex = Steps.findIndex(s => s.id === currentStep.id);
    if (currentStepIndex < Steps.length - 1) {
      onStepChange(Steps[currentStepIndex + 1]);
    } else {
      // Final submission logic
      toast({
        title: 'Ready to File!',
        description: 'Please proceed to the HMRC website to finalize your return.',
      });
    }
  };

  const goBack = () => {
    const currentStepIndex = Steps.findIndex(s => s.id === currentStep.id);
    if (currentStepIndex > 0) {
      onStepChange(Steps[currentStepIndex - 1]);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4 sm:p-8">
      <div className="mb-8 space-y-4">
        <Progress value={(currentStep.id / Steps.length) * 100} className="h-2" />
        <p className="text-center text-sm font-medium text-muted-foreground">
          Step {currentStep.id} of {Steps.length}: {currentStep.name}
        </p>
      </div>

      <Card className="shadow-lg">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(processForm)}>
            <AnimatePresence mode="wait">
              <motion.div
                key={currentStep.id}
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -50 }}
                transition={{ duration: 0.3 }}
                className="min-h-[550px]"
              >
                <RenderStep currentStep={currentStep} form={form} onStepChange={onStepChange} />
              </motion.div>
            </AnimatePresence>

            <div className="flex justify-between p-6 mt-8">
              <Button type="button" variant="outline" onClick={goBack} disabled={currentStep.id === 1}>
                <ArrowLeft className="mr-2 h-4 w-4" /> Go Back
              </Button>
              <Button type="submit" className="bg-accent hover:bg-accent/90">
                {currentStep.id === Steps.length ? 'Finish Review' : 'Next Step'}
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </form>
        </Form>
      </Card>
    </div>
  );
}

const RenderStep = ({ currentStep, form, onStepChange }: { currentStep: Step; form: UseFormReturn<TFormData>, onStepChange: (step: Step) => void; }) => {
  const watchedFormData = form.watch();
  const [showItemizedDeductions, setShowItemizedDeductions] = useState(true);

  const handleSkip = () => {
    const currentStepIndex = Steps.findIndex(s => s.id === currentStep.id);
     if (currentStepIndex < Steps.length - 1) {
        onStepChange(Steps[currentStepIndex + 1])
    }
  };

  switch (currentStep.id) {
    case 1:
      return (
        <CardContent className="p-6 space-y-6">
          <div className="text-center">
            <CardTitle className="text-2xl">Personal Information</CardTitle>
            <CardDescription>Let&apos;s start with the basics.</CardDescription>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="fullName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Full Name</FormLabel>
                  <FormControl>
                    <Input placeholder="John Doe" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="filingStatus"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Filing Status</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a filing status" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {FilingStatusEnum.options.map(status => (
                        <SelectItem key={status} value={status} className="capitalize">{status}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          <FormField
            control={form.control}
            name="addressLine1"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Address Line 1</FormLabel>
                <FormControl>
                  <Input placeholder="123 Main Street" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="addressLine2"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Address Line 2 (Optional)</FormLabel>
                <FormControl>
                  <Input placeholder="Apartment, studio, or floor" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="city"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>City</FormLabel>
                  <FormControl>
                    <Input placeholder="London" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="postcode"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Postcode</FormLabel>
                  <FormControl>
                    <Input placeholder="SW1A 0AA" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </CardContent>
      );
    case 2:
      return (
        <CardContent className="p-6 space-y-8">
           <div className="text-center">
            <CardTitle className="text-2xl">Income & Deductions</CardTitle>
            <CardDescription>Tell us about your primary earnings and expenses.</CardDescription>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="income"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Total Annual Income</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-muted-foreground">
                        £
                      </span>
                      <Input
                        type="number"
                        placeholder="50000"
                        className="pl-7"
                        {...field}
                        onChange={(e) => field.onChange(Number(e.target.value))}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField control={form.control} name="dependents" render={({ field }) => (
              <FormItem><FormLabel>Number of Dependents</FormLabel><FormControl><Input type="number" placeholder="0" {...field} onChange={e => field.onChange(Number(e.target.value))}/></FormControl><FormMessage /></FormItem>
            )} />
          </div>
            <div className="space-y-6">
                 <div className="flex justify-between items-center">
                    <h3 className="text-lg font-medium">Common Deductions</h3>
                    <Button type="button" variant="ghost" size="sm" onClick={() => setShowItemizedDeductions(prev => !prev)}>
                        {showItemizedDeductions ? <EyeOff className="mr-2 h-4 w-4" /> : <Eye className="mr-2 h-4 w-4" />}
                        {showItemizedDeductions ? 'Hide' : 'Show'}
                    </Button>
                </div>
              {showItemizedDeductions && (
                <AnimatePresence>
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6 overflow-hidden"
                >
                    <FormField control={form.control} name="medicalExpenses" render={({ field }) => (<FormItem><FormLabel>Medical Expenses</FormLabel><FormControl><div className="relative"><span className="absolute inset-y-0 left-0 flex items-center pl-3 text-muted-foreground">£</span><Input type="number" placeholder="0" className="pl-7" {...field} onChange={e => field.onChange(Number(e.target.value))}/></div></FormControl></FormItem>)} />
                    <FormField control={form.control} name="mortgageInterest" render={({ field }) => (<FormItem><FormLabel>Mortgage Interest</FormLabel><FormControl><div className="relative"><span className="absolute inset-y-0 left-0 flex items-center pl-3 text-muted-foreground">£</span><Input type="number" placeholder="0" className="pl-7" {...field} onChange={e => field.onChange(Number(e.target.value))}/></div></FormControl></FormItem>)} />
                    <FormField control={form.control} name="charitableDonations" render={({ field }) => (<FormItem><FormLabel>Charitable Donations</FormLabel><FormControl><div className="relative"><span className="absolute inset-y-0 left-0 flex items-center pl-3 text-muted-foreground">£</span><Input type="number" placeholder="0" className="pl-7" {...field} onChange={e => field.onChange(Number(e.target.value))}/></div></FormControl></FormItem>)} />
                </motion.div>
                </AnimatePresence>
              )}
            </div>
        </CardContent>
      );
    case 3:
      return (
        <CardContent className="p-6 space-y-6">
          <div className="text-center">
            <CardTitle className="text-2xl">Other Income</CardTitle>
            <CardDescription>Include income from other sources.</CardDescription>
          </div>
          <FormField
            control={form.control}
            name="pensionsAndBenefits"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="flex items-center"><Briefcase className="mr-2 h-4 w-4" /> Pensions and Benefits</FormLabel>
                <FormControl>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-muted-foreground">£</span>
                    <Input type="number" placeholder="0" className="pl-7" {...field} onChange={(e) => field.onChange(Number(e.target.value))} />
                  </div>
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="propertyIncome"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="flex items-center"><Home className="mr-2 h-4 w-4" /> Property Income</FormLabel>
                <FormControl>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-muted-foreground">£</span>
                    <Input type="number" placeholder="0" className="pl-7" {...field} onChange={(e) => field.onChange(Number(e.target.value))} />
                  </div>
                </FormControl>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="investmentIncome"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="flex items-center"><LineChart className="mr-2 h-4 w-4" /> Investment Income</FormLabel>
                <FormControl>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-muted-foreground">£</span>
                    <Input type="number" placeholder="0" className="pl-7" {...field} onChange={(e) => field.onChange(Number(e.target.value))} />
                  </div>
                </FormControl>
              </FormItem>
            )}
          />
        </CardContent>
      );
    case 4:
        return (
            <CardContent className="p-6 space-y-6 text-center flex flex-col justify-center items-center">
                <Heart className="mx-auto h-12 w-12 text-muted-foreground" />
                <CardTitle className="text-2xl mt-4">Unlock AI Insights</CardTitle>
                <CardDescription className="max-w-md mx-auto">
                    This app is free to use. If you find it helpful, please consider supporting its development. Your contribution helps cover server costs and allows me to keep improving the app.
                </CardDescription>

                <div className="w-full max-w-lg mx-auto">
                  <iframe id='kofiframe' src='https://ko-fi.com/chan913643/?hidefeed=true&widget=true&embed=true&preview=true' style={{border: 'none', width: '100%', padding: '4px', background: '#f9f9f9'}} height='712' title='chan913643'></iframe>
                </div>

                <Button type="button" variant="link" onClick={handleSkip} className="mt-4">Skip and continue</Button>
            </CardContent>
        )
    case 5:
      return (
        <CardContent className="p-6 space-y-6">
            <div className="text-center">
                <Lightbulb className="mx-auto h-12 w-12 text-muted-foreground" />
                <CardTitle className="text-2xl mt-4">AI Financial Assistant</CardTitle>
                <CardDescription>Let our AI find potential tax deductions and efficiency strategies for you.</CardDescription>
            </div>
            <AiDeductions formData={watchedFormData} />
        </CardContent>
      );
    case 6:
      return (
        <CardContent className="p-6 space-y-8">
           <div className="text-center">
            <CardTitle className="text-2xl">Review & Finalize</CardTitle>
            <CardDescription>Review your details and proceed to the official HMRC site to file your return.</CardDescription>
          </div>
          <TaxSummaryCard formData={form.getValues()} />
          <FormField
            control={form.control}
            name="paymentsAndRepayments"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="flex items-center"><Wallet className="mr-2 h-4 w-4" /> Any tax already paid (e.g. through PAYE)</FormLabel>
                <FormControl>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-muted-foreground">£</span>
                    <Input type="number" placeholder="0" className="pl-7" {...field} onChange={(e) => field.onChange(Number(e.target.value))} />
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
           <div className="space-y-4 pt-4 text-center">
                <h3 className="font-semibold text-lg">Ready to File?</h3>
                <CardDescription>
                    You will be redirected to the official HMRC website to complete your Self Assessment tax return.
                </CardDescription>
                <Button asChild size="lg">
                    <Link href="https://www.gov.uk/log-in-file-self-assessment-tax-return" target="_blank">
                        Go to HMRC Website <ExternalLink className="ml-2 h-4 w-4"/>
                    </Link>
                </Button>
            </div>
        </CardContent>
      );
    default:
      return null;
  }
};

    