
'use client';

import { TFormData } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Separator } from '../ui/separator';

interface TaxSummaryCardProps {
  formData: Partial<TFormData>;
}

export function TaxSummaryCard({ formData }: TaxSummaryCardProps) {
    const calculateTax = () => {
    const income = Number(formData.income) || 0;
    const pensions = Number(formData.pensionsAndBenefits) || 0;
    const property = Number(formData.propertyIncome) || 0;
    const investment = Number(formData.investmentIncome) || 0;
    
    const totalIncome = income + pensions + property + investment;

    const medical = Number(formData.medicalExpenses) || 0;
    const mortgage = Number(formData.mortgageInterest) || 0;
    const charity = Number(formData.charitableDonations) || 0;
    const allowances = Number(formData.allowances) || 0;
    const reliefs = Number(formData.reliefs) || 0;
    const studentLoans = Number(formData.studentLoans) || 0;

    const totalDeductions = medical + mortgage + charity + allowances + reliefs + studentLoans;
    const netIncome = Math.max(0, totalIncome - totalDeductions);
    
    // UK Tax Calculation Logic
    const personalAllowanceDefault = 12570;
    
    let personalAllowance = personalAllowanceDefault;
    if (netIncome > 100000) {
      personalAllowance = Math.max(0, personalAllowanceDefault - (netIncome - 100000) / 2);
    }
    
    const taxableIncome = Math.max(0, netIncome - personalAllowance);

    let estimatedTax = 0;
    let taxBreakdown: {band: string, amount: number, rate: string, tax: number}[] = [];
    
    if (taxableIncome > 0) {
        if (taxableIncome <= 12570) {
            taxBreakdown.push({band: 'Personal Allowance', amount: taxableIncome, rate: '0%', tax: 0});
        } else {
            taxBreakdown.push({band: 'Personal Allowance', amount: 12570, rate: '0%', tax: 0});
        }
    }

    if (taxableIncome > 12570) {
        const basicRateAmount = Math.min(taxableIncome - 12570, 50270 - 12570);
        const basicRateTax = basicRateAmount * 0.20;
        estimatedTax += basicRateTax;
        taxBreakdown.push({band: 'Basic rate', amount: basicRateAmount, rate: '20%', tax: basicRateTax});
    }

    if (taxableIncome > 50270) {
        const higherRateAmount = Math.min(taxableIncome - 50270, 125140 - 50270);
        const higherRateTax = higherRateAmount * 0.40;
        estimatedTax += higherRateTax;
        taxBreakdown.push({band: 'Higher rate', amount: higherRateAmount, rate: '40%', tax: higherRateTax});
    }
    
    if (taxableIncome > 125140) {
        const additionalRateAmount = taxableIncome - 125140;
        const additionalRateTax = additionalRateAmount * 0.45;
        estimatedTax += additionalRateTax;
        taxBreakdown.push({band: 'Additional rate', amount: additionalRateAmount, rate: '45%', tax: additionalRateTax});
    }


    const payments = Number(formData.paymentsAndRepayments) || 0;
    const taxOwed = Math.max(0, estimatedTax - payments);
    const totalPayable = taxOwed;


    return {
      income: totalIncome.toLocaleString('en-GB', { style: 'currency', currency: 'GBP' }),
      deductions: totalDeductions.toLocaleString('en-GB', { style: 'currency', currency: 'GBP' }),
      taxableIncome: taxableIncome.toLocaleString('en-GB', { style: 'currency', currency: 'GBP' }),
      estimatedTax: estimatedTax.toLocaleString('en-GB', { style: 'currency', currency: 'GBP' }),
      payments: payments.toLocaleString('en-GB', { style: 'currency', currency: 'GBP' }),
      taxOwed: taxOwed.toLocaleString('en-GB', { style: 'currency', currency: 'GBP' }),
      personalAllowance: personalAllowance.toLocaleString('en-GB', { style: 'currency', currency: 'GBP' }),
      taxBreakdown: taxBreakdown,
      totalPayable: totalPayable.toLocaleString('en-GB', { style: 'currency', currency: 'GBP' }),
    };
  };

  const summary = calculateTax();

  return (
    <Card>
      <CardHeader>
        <CardTitle>Estimated Tax Summary</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex justify-between">
          <span className="text-muted-foreground">Total Income</span>
          <span>{summary.income}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-muted-foreground">Total Deductions & Reliefs</span>
          <span>{summary.deductions}</span>
        </div>
         <div className="flex justify-between">
          <span className="text-muted-foreground">Personal Allowance</span>
          <span>{summary.personalAllowance}</span>
        </div>
        <div className="flex justify-between font-semibold">
          <span >Taxable Income</span>
          <span>{summary.taxableIncome}</span>
        </div>
        <Separator />
         <div className="space-y-2">
            <h4 className="font-semibold">Tax Breakdown:</h4>
            {summary.taxBreakdown.map(item => (
                <div key={item.band} className="flex justify-between items-center text-sm ml-4">
                     <span>{item.band} ({item.amount.toLocaleString('en-GB', { style: 'currency', currency: 'GBP' })} @ {item.rate})</span>
                     <span>{item.tax.toLocaleString('en-GB', { style: 'currency', currency: 'GBP' })}</span>
                </div>
            ))}
         </div>
        <Separator />
         <div className="flex justify-between">
          <span className="text-muted-foreground">Estimated Tax</span>
          <span>{summary.estimatedTax}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-muted-foreground">Payments Already Made</span>
          <span>{summary.payments}</span>
        </div>
        <div className="flex justify-between font-bold text-lg text-accent">
          <span>Total To Pay</span>
          <span>{summary.totalPayable}</span>
        </div>
        <p className="text-xs text-muted-foreground pt-4">
          This is a simplified estimate for illustrative purposes only. Actual tax liability may vary based on UK tax laws.
        </p>
      </CardContent>
    </Card>
  );
}
