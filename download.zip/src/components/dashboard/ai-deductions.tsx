
'use client';

import { useState } from 'react';
import { Lightbulb, PiggyBank, Star, XCircle } from 'lucide-react';
import { suggestDeductions, type SuggestDeductionsInput, type SuggestDeductionsOutput } from '@/ai/flows/suggest-deductions';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TaxEfficiency } from './tax-efficiency';
import { cn } from '@/lib/utils';
import { Separator } from '../ui/separator';

interface AiDeductionsProps {
  formData: Partial<SuggestDeductionsInput>;
}

type Deduction = SuggestDeductionsOutput['suggestedDeductions'][0];

export function AiDeductions({ formData }: AiDeductionsProps) {
  const [suggestions, setSuggestions] = useState<Deduction[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleGetSuggestions = async () => {
    if (formData.income === undefined || formData.filingStatus === undefined || formData.dependents === undefined) {
      toast({
        variant: 'destructive',
        title: 'Missing Information',
        description: 'Please provide income, filing status, and number of dependents before getting suggestions.',
      });
      return;
    }

    const apiInput: SuggestDeductionsInput = {
      income: Number(formData.income) || 0,
      filingStatus: formData.filingStatus,
      dependents: Number(formData.dependents) || 0,
      itemizedDeductions: formData.itemizedDeductions || false,
      ...(formData.itemizedDeductions && {
        medicalExpenses: Number(formData.medicalExpenses) || 0,
        mortgageInterest: Number(formData.mortgageInterest) || 0,
        charitableDonations: Number(formData.charitableDonations) || 0,
      }),
      pensionsAndBenefits: Number(formData.pensionsAndBenefits) || 0,
      propertyIncome: Number(formData.propertyIncome) || 0,
      investmentIncome: Number(formData.investmentIncome) || 0,
      allowances: Number(formData.allowances) || 0,
      reliefs: Number(formData.reliefs) || 0,
      studentLoans: Number(formData.studentLoans) || 0,
    };

    setIsLoading(true);
    setSuggestions([]);
    try {
      const result = await suggestDeductions(apiInput);
      setSuggestions(result.suggestedDeductions);
    } catch (error) {
      console.error('Failed to get AI suggestions:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Could not fetch AI suggestions. Please try again later.',
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const likelyDeductions = suggestions.filter(s => s.applicability === 'Highly Likely');
  const potentialDeductions = suggestions.filter(s => s.applicability === 'Potential');
  const notApplicableDeductions = suggestions.filter(s => s.applicability === 'Not Applicable');

  return (
    <Card className="bg-card/50">
        <Tabs defaultValue="deductions">
            <CardHeader>
                <div className="flex items-start justify-between gap-4">
                    <div>
                        <CardTitle>AI Financial Assistant</CardTitle>
                        <CardDescription>Unlock personalized financial advice.</CardDescription>
                    </div>
                    <TabsList>
                        <TabsTrigger value="deductions"><Lightbulb className="mr-2 h-4 w-4" /> Deductions</TabsTrigger>
                        <TabsTrigger value="efficiency"><PiggyBank className="mr-2 h-4 w-4" /> Tax Efficiency</TabsTrigger>
                    </TabsList>
                </div>
            </CardHeader>
            <TabsContent value="deductions" className="p-0">
                <CardContent className="space-y-6">
                    <Button onClick={handleGetSuggestions} disabled={isLoading}>
                    {isLoading ? 'Analyzing...' : 'Get Deduction Suggestions'}
                    </Button>

                    {isLoading && (
                    <div className="space-y-4 pt-4">
                        <h3 className="mb-4 font-semibold">Analyzing your data for deductions...</h3>
                        <Skeleton className="h-12 w-full" />
                        <Skeleton className="h-12 w-full" />
                        <Skeleton className="h-12 w-full" />
                    </div>
                    )}
                    
                    {suggestions.length > 0 && (
                    <div className="space-y-6">
                        {likelyDeductions.length > 0 && (
                            <div>
                                <h3 className="mb-4 font-semibold text-green-600 dark:text-green-400">Highly Likely Deductions</h3>
                                <Accordion type="single" collapsible className="w-full">
                                {likelyDeductions.map((suggestion, index) => (
                                    <AccordionItem value={`likely-item-${index}`} key={`likely-${index}`}>
                                        <AccordionTrigger className="text-green-600 dark:text-green-400 font-bold">
                                            <div className="flex items-center gap-2">
                                                <Star className="h-4 w-4 fill-green-500 text-green-600" />
                                                {suggestion.name}
                                            </div>
                                        </AccordionTrigger>
                                    <AccordionContent>
                                        {suggestion.explanation}
                                        <p className="text-xs text-muted-foreground mt-2">We recommend consulting with a tax professional to confirm your eligibility.</p>
                                    </AccordionContent>
                                    </AccordionItem>
                                ))}
                                </Accordion>
                            </div>
                        )}

                        {potentialDeductions.length > 0 && (
                            <div>
                                {(likelyDeductions.length > 0) && <Separator className="my-6" />}
                                <h3 className="mb-4 font-semibold">Potential Deductions</h3>
                                <p className="text-sm text-muted-foreground mb-4">These may apply depending on your specific circumstances. Please read through to determine your eligibility.</p>
                                <Accordion type="single" collapsible className="w-full">
                                {potentialDeductions.map((suggestion, index) => (
                                    <AccordionItem value={`potential-item-${index}`} key={`potential-${index}`}>
                                    <AccordionTrigger>
                                        <div className="flex items-center gap-2">
                                            {suggestion.name}
                                        </div>
                                    </AccordionTrigger>
                                    <AccordionContent>
                                        {suggestion.explanation}
                                        <p className="text-xs text-muted-foreground mt-2">We recommend consulting with a tax professional to confirm your eligibility.</p>
                                    </AccordionContent>
                                    </AccordionItem>
                                ))}
                                </Accordion>
                            </div>
                        )}

                        {notApplicableDeductions.length > 0 && (
                             <div>
                                {(likelyDeductions.length > 0 || potentialDeductions.length > 0) && <Separator className="my-6" />}
                                <h3 className="mb-4 font-semibold">Not Applicable</h3>
                                <p className="text-sm text-muted-foreground mb-4">These deductions do not apply to you. The explanations are for your future reference.</p>
                                <Accordion type="single" collapsible className="w-full">
                                {notApplicableDeductions.map((suggestion, index) => (
                                    <AccordionItem value={`not-applicable-item-${index}`} key={`not-applicable-${index}`}>
                                    <AccordionTrigger className="text-muted-foreground">
                                        <div className="flex items-center gap-2">
                                             <XCircle className="h-4 w-4 text-muted-foreground" />
                                            {suggestion.name}
                                        </div>
                                    </AccordionTrigger>
                                    <AccordionContent>
                                        {suggestion.explanation}
                                    </AccordionContent>
                                    </AccordionItem>
                                ))}
                                </Accordion>
                            </div>
                        )}
                    </div>
                    )}
                </CardContent>
            </TabsContent>
            <TabsContent value="efficiency" className="p-0">
                 <TaxEfficiency formData={formData}/>
            </TabsContent>
        </Tabs>
    </Card>
  );
}
