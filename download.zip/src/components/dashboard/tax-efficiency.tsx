
'use client';

import { useState, useEffect } from 'react';
import { PiggyBank } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { suggestTaxEfficiency, type SuggestTaxEfficiencyInput, type SuggestTaxEfficiencyOutput } from '@/ai/flows/suggest-tax-efficiency';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

interface TaxEfficiencyProps {
  formData: Partial<SuggestTaxEfficiencyInput & {
    pensionsAndBenefits?: number;
    propertyIncome?: number;
    investmentIncome?: number;
  }>;
}

const taxEfficiencyFormSchema = z.object({
  targetIncome: z.coerce.number().min(1, "Target income must be greater than zero."),
  currentSavings: z.coerce.number().min(0, "Current savings cannot be negative."),
  riskAppetite: z.enum(['low', 'medium', 'high']),
});

type TaxEfficiencyFormData = z.infer<typeof taxEfficiencyFormSchema>;

export function TaxEfficiency({ formData }: TaxEfficiencyProps) {
  const [suggestions, setSuggestions] = useState<SuggestTaxEfficiencyOutput | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const calculateTotalIncome = () => {
    return (
      (formData.income || 0) +
      (formData.pensionsAndBenefits || 0) +
      (formData.propertyIncome || 0) +
      (formData.investmentIncome || 0)
    );
  };

  const totalIncome = calculateTotalIncome();

  const form = useForm<TaxEfficiencyFormData>({
    resolver: zodResolver(taxEfficiencyFormSchema),
    defaultValues: {
      targetIncome: totalIncome > 0 ? totalIncome * 1.5 : 50000,
      currentSavings: 0,
      riskAppetite: 'medium',
    },
  });

  useEffect(() => {
    const newTotalIncome = calculateTotalIncome();
    form.reset({
      targetIncome: newTotalIncome > 0 ? newTotalIncome * 1.5 : 50000,
      currentSavings: form.getValues('currentSavings') || 0,
      riskAppetite: form.getValues('riskAppetite') || 'medium',
    });
  }, [formData.income, formData.pensionsAndBenefits, formData.propertyIncome, formData.investmentIncome, form]);


  const handleGetSuggestions = async (data: TaxEfficiencyFormData) => {
    const currentTotalIncome = calculateTotalIncome();
    
    if (currentTotalIncome === 0) {
      toast({
        variant: 'destructive',
        title: 'Missing Information',
        description: 'Your current income is needed to generate a plan. Please fill out the income sections first.',
      });
      return;
    }

    const apiInput: SuggestTaxEfficiencyInput = {
      income: currentTotalIncome,
      targetIncome: data.targetIncome,
      currentSavings: data.currentSavings,
      riskAppetite: data.riskAppetite,
    };

    setIsLoading(true);
    setSuggestions(null);
    try {
      const result = await suggestTaxEfficiency(apiInput);
      setSuggestions(result);
    } catch (error) {
      console.error('Failed to get AI suggestions:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Could not fetch AI suggestions. Please try again later.',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <CardContent className="space-y-6">
        <p className="text-sm text-muted-foreground">Get a personalized plan to help you save and invest efficiently to reach your financial goals.</p>
        <Form {...form}>
            <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <FormField control={form.control} name="targetIncome" render={({ field }) => (
                        <FormItem>
                            <FormLabel>Target Annual Income</FormLabel>
                            <FormControl><div className="relative"><span className="absolute inset-y-0 left-0 flex items-center pl-3 text-muted-foreground">£</span><Input type="number" placeholder="75000" className="pl-7" {...field} /></div></FormControl>
                            <FormMessage />
                        </FormItem>
                    )} />
                     <FormField control={form.control} name="currentSavings" render={({ field }) => (
                        <FormItem>
                            <FormLabel>Current Savings/Investments</FormLabel>
                            <FormControl><div className="relative"><span className="absolute inset-y-0 left-0 flex items-center pl-3 text-muted-foreground">£</span><Input type="number" placeholder="10000" className="pl-7" {...field} /></div></FormControl>
                            <FormMessage />
                        </FormItem>
                    )} />
                     <FormField control={form.control} name="riskAppetite" render={({ field }) => (
                        <FormItem>
                            <FormLabel>Risk Appetite</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl><SelectTrigger><SelectValue placeholder="Select your risk appetite" /></SelectTrigger></FormControl>
                                <SelectContent>
                                    <SelectItem value="low">Low</SelectItem>
                                    <SelectItem value="medium">Medium</SelectItem>
                                    <SelectItem value="high">High</SelectItem>
                                </SelectContent>
                            </Select>
                            <FormMessage />
                        </FormItem>
                    )} />
                </div>
                <Button type="button" onClick={form.handleSubmit(handleGetSuggestions)} disabled={isLoading}>
                    {isLoading ? 'Generating Plan...' : 'Get Tax Efficiency Plan'}
                </Button>
            </div>
        </Form>

        {isLoading && (
            <div className="space-y-4 pt-4">
                <h3 className="mb-4 font-semibold">Generating your personalized financial plan...</h3>
                <Skeleton className="h-24 w-full" />
                <Skeleton className="h-12 w-full" />
                <Skeleton className="h-12 w-full" />
            </div>
        )}

        {suggestions && (
            <div className="space-y-6 pt-4">
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center"><PiggyBank className="mr-2 h-6 w-6 text-accent" /> Your Savings Plan</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-2xl font-bold text-accent">£{suggestions.savingsPlan.monthlySavingsRequired.toLocaleString()}</p>
                        <p className="text-muted-foreground">Required monthly savings</p>
                        <p className="mt-4">{suggestions.savingsPlan.planDescription}</p>
                    </CardContent>
                </Card>

                <div>
                    <h3 className="mb-4 text-lg font-semibold">Suggested Investments:</h3>
                    <Accordion type="single" collapsible className="w-full">
                        {suggestions.investmentSuggestions.map((suggestion, index) => (
                            <AccordionItem value={`item-${index}`} key={index}>
                                <AccordionTrigger>
                                    <div className="flex justify-between w-full pr-4">
                                        <span>{suggestion.name}</span>
                                        <span className="text-accent font-semibold">{suggestion.potentialReturn}</span>
                                    </div>
                                </AccordionTrigger>
                                <AccordionContent>
                                    {suggestion.description}
                                     <p className="text-xs text-muted-foreground mt-2">This is not financial advice. Past performance is not indicative of future results. We recommend consulting with a qualified financial advisor.</p>
                                </AccordionContent>
                            </AccordionItem>
                        ))}
                    </Accordion>
                </div>
            </div>
        )}
    </CardContent>
  );
}

    