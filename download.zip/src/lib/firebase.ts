
// Import the functions you need from the SDKs you need
import { getApps, initializeApp, getApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBJhUCKKdtVLo5kLSYE34hnj6QU2UxC6FA",
    authDomain: "taxmate-j15tr.firebaseapp.com",
    projectId: "taxmate-j15tr",
    storageBucket: "taxmate-j15tr.appspot.com",
    messagingSenderId: "450541013738",
    appId: "1:450541013738:web:fd8db93c74e61ac2b3e593"
};

// Initialize Firebase for SSR
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
const auth = getAuth(app);
const db = getFirestore(app);
const googleProvider = new GoogleAuthProvider();

export { app, auth, db, googleProvider };
