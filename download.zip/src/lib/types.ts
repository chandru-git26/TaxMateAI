import { z } from 'zod';

export const FilingStatusEnum = z.enum([
  'single',
  'married filing jointly',
  'married filing separately',
  'head of household',
  'qualifying widow(er)',
]);

export const FormDataSchema = z.object({
  // Personal Info
  fullName: z.string().min(1, 'Full name is required'),
  filingStatus: FilingStatusEnum,
  addressLine1: z.string().min(1, 'Address is required'),
  addressLine2: z.string().optional(),
  city: z.string().min(1, 'City is required'),
  postcode: z.string().min(1, 'Postcode is required'),
  
  // Income and Deductions
  income: z.coerce.number().min(0, 'Income must be a positive number'),
  dependents: z.coerce.number().int().min(0, 'Dependents must be a positive number'),
  itemizedDeductions: z.boolean().default(false),
  medicalExpenses: z.coerce.number().optional(),
  mortgageInterest: z.coerce.number().optional(),
  charitableDonations: z.coerce.number().optional(),

  // New Fields
  pensionsAndBenefits: z.coerce.number().optional(),
  propertyIncome: z.coerce.number().optional(),
  investmentIncome: z.coerce.number().optional(),
  allowances: z.coerce.number().optional(),
  reliefs: z.coerce.number().optional(),
  studentLoans: z.coerce.number().optional(),
  paymentsAndRepayments: z.coerce.number().optional(),

  // Payment - Removed
  cardName: z.string().optional(),
  cardNumber: z.string().optional(),
  cardExpiry: z.string().optional(),
  cardCVC: z.string().optional(),
});

export type TFormData = z.infer<typeof FormDataSchema>;

export const Steps = [
  { id: 1, name: 'Personal Information' },
  { id: 2, name: 'Income & Deductions' },
  { id: 3, name: 'Other Income & Reliefs' },
  { id: 4, name: 'Unlock AI Insights' },
  { id: 5, name: 'AI Deduction Finder' },
  { id: 6, name: 'Review & File' },
] as const;

export type Step = (typeof Steps)[number];

    

    